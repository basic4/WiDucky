package bd.blue3;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.media.audiofx.EnvironmentalReverb;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.MainThread;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.io.File;
import java.io.FileReader;
import java.net.Socket;
import java.net.SocketAddress;
import java.io.BufferedInputStream;
import android.widget.ListView;
import android.widget.Toast;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;


public class MainActivity extends Activity {
    TextView myLabel;
    EditText myTextbox;
    TextView myConsole;
    Spinner myFile;
    String inputScript = "";
    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    InetAddress duckAddress;
    Socket rfSocket;
    OutputStream mmOutputStream;
    InputStream mmInputStream;
    public BufferedInputStream xs;

    WifiConfiguration wifiConfig;
    WifiManager wifiMan;
    String addsx = "";
    Thread workerThread;
    int systemType = 1;  //BT-0, wifi-1
    String wifiAddress = "192.168.4.1";
    String APName = "WiDucky";
    byte[] readBuffer;
    int readBufferPosition;
    int counter;
    volatile boolean stopWorker;
    volatile boolean sendError;
    String mapType = "US";
    int inputMode = 0;
    int controlMode = 0;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button openButton = (Button) findViewById(R.id.open);
        Button sendButton = (Button) findViewById(R.id.send);
        Button closeButton = (Button) findViewById(R.id.close);
        Button loadButton = (Button) findViewById(R.id.load);
        Button runButton = (Button) findViewById(R.id.run);
        Button hexButton = (Button) findViewById(R.id.hex);
        myLabel = (TextView) findViewById(R.id.label);
        myTextbox = (EditText) findViewById(R.id.entry);
        myConsole = (TextView) findViewById(R.id.txtConsole);
        myFile = (Spinner) findViewById(R.id.spinner);
        myConsole.setText("");
        //Open Button
        openButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    myConsole.setText("");
                    if(systemType > 0)
                    {
                        //Wifi
                        int wifiState = findWifi(APName,"quackings",1);
                        openWifi();

                    }
                    else {
                        //Bluetooth
                        findBT();
                        openBT();
                    }
                }
                catch (IOException ex)
                {
                    ex = null;
                    userMessage("Error Opening Connection.");
                }
            }
        });

        //Send Button
        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                    if(myTextbox.getText().length() > 0) {
                        if (inputMode == 0)
                        {
                            String cmd = myTextbox.getText().toString();
                            processLine(cmd.toString());
                        }
                        else
                        {
                            //Hex mode
                            processHex(myTextbox.getText().toString());
                        }
                        myConsole.append("[SENT] " + myTextbox.getText().toString() +  System.lineSeparator());
                        myConsole.append("[COMMAND PROCESSING COMPLETE]" + System.lineSeparator() + System.lineSeparator());
                    }
            }
        });

        //Close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(systemType < 1) {
                    closeBT();
                    myLabel.setText("Adapter Closed");
                    userMessage("Adapter Closed");
                }
                else
                {
                    closeWifi();
                    myLabel.setText("Wifi Connection Closed");
                    userMessage("Wifi Connection Closed");
                }
            }
        });

        //Open Button
        loadButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                listScripts();
            }
        });

        hexButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                changeMode();
            }
        });


        runButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String filex = myFile.getSelectedItem().toString();
                String scriptFile = LoadScript(filex);
                userMessage("File Loaded");
                String[] commands = parseFile(scriptFile);
                if(commands.length > 0)
                {
                    myConsole.append("[SCRIPT]" + System.lineSeparator());
                    for (String line : commands)
                    {
                        processLine(line);
                        myConsole.append(line.toString() + System.lineSeparator());

                    }
                    myConsole.append("[SCRIPT_ENDS]" + System.lineSeparator());
                    myLabel.setText("Script SEND Completed (" + commands.length + ")");
                    userMessage("Script SEND Completed (" + commands.length + ")");
                }
                else
                {
                    myLabel.setText("No Script Loaded!");
                    userMessage("No Script Loaded!");
                }

            }
        });

    }

    void findBT() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            myLabel.setText("No Bluetooth Adapter Available");
            userMessage("No Bluetooth Adapter Available");
        }

        if (mBluetoothAdapter.isEnabled() == false) {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices)
            {
                if (device.getName().equals("BlueDuck"))
                {
                    mmDevice = device;
                    break;
                }
            }
        }
        myLabel.setText("Bluetooth Device Found");
        userMessage("Bluetooth Device Found");
    }

    void userMessage (String message)
    {
        Context context = getApplicationContext();
        CharSequence text = message;
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    void changeMode()
    {
        Button hexButton = (Button) findViewById(R.id.hex);
        if(inputMode ==1)
        {
            hexButton.setText("CHR");
            inputMode  = 0;
        }
        else
        {
            hexButton.setText("HEX");
            inputMode  = 1;
        }
    }

    void processHex(String inx)
    {
        if(inx.length() > 2)
        {
            //multi-byte?
            if(inx.indexOf(":") > 0)
            {
                inx = inx.replaceAll("\\r?\\n","");
                String parts[]  = inx.split(":");
                for (String p : parts)
                {
                    p = p.replaceAll(":", "");
                    int y = Integer.parseInt(p,16);
                    sendData(y & 0xff);
                    //waitTime(250);
                }
            }
        }
        else
        {
            //single byte value
            int y = Integer.parseInt(inx,16);
            sendData(y & 0xff);
        }

    }

    int findWifi(String ap, String password, int connType) throws IOException
    {
        int state = -1;
        int netID  = -1;
        wifiConfig = new WifiConfiguration();
        wifiConfig.SSID = ap;
        wifiConfig.preSharedKey = password;

        wifiMan = (WifiManager)getSystemService(WIFI_SERVICE);
        ap = "\"" + ap + "\"";

        for (WifiConfiguration thisConfig : wifiMan.getConfiguredNetworks())
        {
            if(thisConfig.SSID.toString().equals(ap.toString()))
            {
                wifiConfig = thisConfig;
                netID = wifiMan.addNetwork(wifiConfig);
                break;
            }
        }


        if( netID > -1)
        {
            String currentSSID = wifiMan.getConnectionInfo().getSSID();
            wifiMan.disconnect();
            makeDelay(500);
            wifiMan.enableNetwork(netID, true);
            makeDelay(500);
            wifiMan.reconnect();
            makeDelay(500);
            state = wifiMan.getWifiState();

            myLabel.setText("Wifi Station Found");
            userMessage("Wifi Station Found");
        }
        else
        {
            //Can't add the network
            userMessage("Can't add Wifi Station.");

        }

        return(state);
    }

    boolean makeSocket()
    {
        try
        {
            //Naughty - but I can't get the threaded approach working
            //for some reason.
            StrictMode.ThreadPolicy tp = StrictMode.ThreadPolicy.LAX;
            StrictMode.setThreadPolicy(tp);
            //Open the Socket to the WiDuck
            makeDelay(1500);
            rfSocket = new Socket();
            rfSocket.connect(new InetSocketAddress(wifiAddress, 6673), 5000);
            makeDelay(500);
            return(true);
        }
        catch (Exception ex)
        {
            ex = null;
            return(false);
        }
    }

    void openWifi()
    {
        try
        {
            if(makeSocket())
            {
                mmOutputStream  = rfSocket.getOutputStream();
                mmInputStream  = rfSocket.getInputStream();
                xs = new BufferedInputStream(mmInputStream,4096);
                beginListenForData();
                myLabel.setText("WifiDuck Online");
                userMessage("WifiDuck Online");
            }
            else
            {
                myLabel.setText("No Socket");
                userMessage("WifiDuck offline - Socket Issue");
            }

        }
        catch (Exception ex)
        {
            myLabel.setText("Can't Open Stream.");
            String reason  = ex.getMessage();
            userMessage("WifiDuck OffLine - " + reason);
            ex = null;
        }

    }


    void openBT() throws IOException {
        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
        mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
        mmSocket.connect();
        mmOutputStream = mmSocket.getOutputStream();
        mmInputStream = mmSocket.getInputStream();
        beginListenForData();
        myLabel.setText("BlueDuck Online");
        userMessage("BlueDuck Online");
    }

    void beginListenForData() {
        final Handler handler = new Handler();
        final byte delimiter = 10; //This is the ASCII code for a newline character

        stopWorker = false;
        workerThread = new Thread(new Runnable() {
            public void run() {
                while (!Thread.currentThread().isInterrupted() && !stopWorker) {
                    try {
                        int avx = xs.available();
                        if (avx > 0) {
                            byte[] buff = new byte[avx];
                            addsx = "";
                            xs.read(buff);
                            //for (byte t: buff)
                            //{
                            //    addsx += (char)t;
                            //}
                            addsx = new String(buff);
                            addsx.replaceAll("\n", System.lineSeparator());
                            addsx.replaceAll("\r", "");
                            handler.post(new Runnable() {
                                public void run() {

                                    myConsole.append(addsx);
                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    char replaceKey(char inp)
    {
        char repKey = inp;
        switch (mapType)
        {
            case "UK":
                switch ((int) inp)
                {
                    case 64:
                        //@
                        repKey = (char) 34;
                        break;
                    case 34:
                        // "
                        repKey = (char) 64;
                        break;
                    case 35:
                        //#
                        repKey = (char) 186;
                        break;
                    case 126:
                        //~
                        repKey = (char) 124;
                        break;
                    case 47:
                        // Forward slash (/)
                        repKey = (char) 192;
                        break;
                    case 92:
                        // Back slash (\)
                        repKey = (char) 0xec;
                        break;
                    default:
                        repKey = inp;
                        break;
                }

                return (repKey);
        }
        return (repKey);
    }

    void sendData(String inpx) {
        try {
            for (byte b : inpx.getBytes())
            {
                char t = replaceKey((char) b);
                int y = (int) t;
                mmOutputStream.write(y & 0xff);
            }
            mmOutputStream.flush();
        }
        catch (IOException ex)
        {
            sendError = true;
            ex = null;
            userMessage("Error Sending Command!!!");
        }
    }

    void sendCommandData(String inputx)
    {
        try {
            String msg = inputx;
            msg += "\n";
            for (byte b : msg.getBytes())
            {
                mmOutputStream.write(replaceKey((char) (b & 0xff)));
            }
            myTextbox.setText("");
            mmOutputStream.flush();
        }
        catch (IOException ex)
        {
            sendError = true;
            ex = null;
            userMessage("Error Sending Command!!!");
        }
    }


    void sendData(byte inx)
    {
        try
        {
            waitTime(2);
            int y = (int)inx;
            mmOutputStream.write(y & 0xff);
            mmOutputStream.flush();
        }
        catch(IOException ex)
        {
            sendError = true;
            ex = null;
            userMessage("Error Sending Command!!!");
        }
    }


    void sendData(int ipx)
    {
        try
        {
            waitTime(2);
            ipx = ipx & 0xff;
            mmOutputStream.write(ipx);
            mmOutputStream.flush();
        }
        catch (IOException ex)
        {
            sendError = true;
            ex = null;
            userMessage("Error Sending Command!!!");
        }
    }

    void closeBT()
    {
        stopWorker = true;
        try
        {
            mmOutputStream.close();
            mmInputStream.close();
            mmSocket.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        myLabel.setText("Bluetooth Closed");
        userMessage("No Bluetooth Adapter Available");
    }

    void closeWifi()
    {
        stopWorker = true;
        try
        {
            mmOutputStream.close();
            mmInputStream.close();
            rfSocket.close();
        }
        catch (Exception ex)
        {
            ex = null;
            userMessage("Error Closing WiFi AP.");
        }
        myLabel.setText("Wifi Closed");
        userMessage("No Wifi AP Available");
    }


    int getKeyCode(String subcom)
    {
        int resultant = 0;
        int keyVal = -1;
        switch(subcom)
        {
            case "CTRL":
                resultant = 128;
                break;
            case "ENTER":
                resultant  = 131;
                break;
            case "SHIFT":
                //left shift
                resultant = 129;
                break;
            case "ALT":
                resultant = 130;
                break;
            case "TAB":
                resultant = 179;
                break;
            case "GUI":
                //left GUI (windows)
                resultant = 131;
                break;
            case "GUI_R":
                resultant = 135;
                break;
            case "ESC":
                resultant = 177;
                break;
            case "BACKSPACE":
                resultant = 178;
                break;
            case "INS":
                resultant = 209;
                break;
            case "DEL":
                resultant = 212;
                break;
            case "HOME":
                resultant = 210;
                break;
            case "ALTGR":
                resultant = 134;
                break;
            case "CTRLR":
                resultant = 132;
                break;
            case "SHIFTR":
                resultant = 133;
                break;
            case "F1":
                resultant = 194;
                break;
            case "F2":
                resultant = 195;
                break;
            case "F3":
                resultant = 196;
                break;
            case "F4":
                resultant = 197;
                break;
            case "F5":
                resultant = 198;
                break;
            case "F6":
                resultant = 199;
                break;
            case "F7":
                resultant = 200;
                break;
            case "F8":
                resultant = 201;
                break;
            case "F9":
                resultant = 202;
                break;
            case "F10":
                resultant = 203;
                break;
            case "F11":
                resultant = 204;
                break;
            case "F12":
                resultant = 205;
                break;
            case "CAPS_LOCK":
                resultant = 193;
                break;
            case "PAGE_UP":
                resultant = 211;
                break;
            case "PAGE_DOWN":
                resultant = 214;
                break;
            case "UP":
                resultant = 218;
                break;
            case "DWN":
                resultant = 217;
                break;
            case "LFT":
                resultant = 216;
                break;
            case "RHT":
                resultant = 215;
                break;
            default:
                resultant = keyVal;
                break;
        }
        return (resultant);
    }

    void listScripts()
    {
        //Find any .txt files in the current folder
        //and list these in the spinner
        //String yourDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/BDscripts";
        String yourDir = "/mnt/ext_sdcard/BDscripts";
        userMessage("load.." + yourDir);
        File folder = new File(yourDir);

        ArrayList<String> fxs = new ArrayList<String>();
        if (folder.exists())
        {
            File[] theseFiles = folder.listFiles();
            if(theseFiles != null)
            {
                for (File f : theseFiles) {
                    if (f.isFile() & f.getName().endsWith(".txt"))
                    {
                        fxs.add(f.getName());
                    }
                }
            }
            else
            {
                myLabel.setText("No Files in BDscripts");
                userMessage("No Files in BDscripts Folder");
                return;
            }
        }
        else
        {
            myLabel.setText("No BD Folder");
            userMessage("No BDscripts folder on SD Card!");
            return;
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, fxs);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        myFile.setAdapter(dataAdapter);
    }


    String[] parseFile(String inputx)
    {
        //break the file into lines
        String[] output = inputx.split("\\r?\\n");
        return (output);
    }

    int getNumericPad(char inx)
    {
        //Ruturn the corresponding numeric pad
        //keycode
        int vx = Character.getNumericValue(inx);
        if(vx > 0) {
            return (vx + 224);
        }
        else{
            return (234);
        }
    }

    void makeDelay(int Twomillsecs)
    {
        long tick =2;
        while (Twomillsecs > 0)
        {
            try
            {
                Thread.sleep(tick);
                Twomillsecs --;
            }
            catch (InterruptedException ex)
            {
                ex.printStackTrace();
            }
        }
        return;
    }
    void waitTime(int MillSecs)
    {
        double x = 2.345445;
        long startTime = System.currentTimeMillis();
        while ((startTime + (long) MillSecs) > System.currentTimeMillis())
        {
            x += 0.45697861;
        }
        return;
    }


    public String LoadScript(String filename)
    {
        String content = null;
        String dir = "/mnt/ext_sdcard/BDscripts/";
        File file = new File(dir + filename);
        FileReader reader = null;
        try
        {
            reader = new FileReader(file);
            char[] chars = new char[(int) file.length()];
            reader.read(chars);
            content = new String(chars);
        }
        catch(FileNotFoundException e)
        {
            myLabel.setText("File not found ");
            userMessage("File Not Found");
        }
        catch (IOException e) {
            myLabel.setText("Error loading ");
            userMessage("Error Loading" + e.getMessage());
        }
         finally {
            if(reader !=null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException ex)
                {
                    ex.printStackTrace();
                }
            }
        }
        return content;
    }

    void processLine(String comline)
    {
        String[] parts;

        if(comline.startsWith("STRING"))
        {
            //Send the string chars one at a time
            String resultant = comline.substring(7);
            sendData(resultant);
            return;
        }
        else if (comline.startsWith("DELAY"))
        {
            //Wait given millsecs
            int delTime = Integer.parseInt(comline.substring(6));
            if(delTime > 0) {
                try
                {
                    long txms = (long)delTime;
                    Thread.sleep(txms);
                }
                catch (InterruptedException e)
                {
                    Thread.currentThread().interrupt();
                }
            }
            return;
        }
        else if(comline.startsWith("ENTER"))
        {
            //Send a Return
            byte k = (byte)176;  //'B0'
            sendData(k);
            return;
        }
        else if (comline.startsWith("COMD"))
        {
            //Send full command line plus return
            String resultant = comline.substring(5);
            sendCommandData(resultant);
            return;
        }
        else if (comline.startsWith("VER"))
        {
            sendData(250 & 0xff);
            return;
        }
        else if(comline.startsWith("KEY"))
        {
            //Send a windows ALT key combo (eg. 'ALT + 0124')
            //Windows ALT keys(
            sendData(252 & 0xff);
            //numberpad keys inputs
            String nums = comline.substring(4);
            nums = nums.replaceAll(" ","");
            nums = nums.replaceAll(System.lineSeparator(), "");
            for(int x=0;x<nums.length();x++)
            {
                char b = nums.charAt(x);
                int ky = getNumericPad(nums.charAt(x));
                sendData(ky & 0xff);
            }
            //signal sequence end
            sendData(253 & 0xff);
            return;
        }
        else if(comline.startsWith("MAP"))
        {
            String typx = comline.substring(4);
            typx = typx.replace(" ","");
            typx = typx.replaceAll(System.lineSeparator(), "");
            mapType = typx;
            return;
        }
        else if(comline.startsWith("RAW"))
        {
            //Raw hex data command
            comline = comline.substring(4).toString();
            comline = comline.replaceAll(System.lineSeparator(), "");
            comline  = comline.replaceAll(" ", "");
            int y = Integer.parseInt(comline,16);
            sendData(y & 0xff);
            return;
        }
        else if(comline.startsWith("MODE"))
        {
            //Set comms mode: 1: ser/ser  0: key/ser
            comline = comline.substring(5).toString();
            comline = comline.replaceAll(System.lineSeparator(), "");
            comline  = comline.replaceAll(" ", "");
            int y = Integer.parseInt(comline);
            if(y > 0)
            {
                //set mode 1: Ser / Ser
                sendData(255 & 0xff);
                controlMode = 1;
            }
            else
            {
                //set mode 0: Key / Ser
                sendData(249 & 0xff);
                controlMode = 0;
            }
            return;

        }
        else
        {
            //Compound Command or Special Key
            String dif = "+";
            if(comline.indexOf(dif) > 0)
            {
                //Multi-Key Special Character
                comline = comline.replaceAll("\\r?\\n","");
                parts = comline.split("\\+");

                sendData(251 & 0xff); //signal multi start
                for(String part :  parts)
                {
                    part = part.replaceAll(" ", "");
                    if(getKeyCode(part) > 0)
                    {
                        sendData(getKeyCode(part) & 0xff);
                    }
                    else
                    {
                        sendData(part);
                    }
                    waitTime(100);
                }
                sendData(254 & 0xff); //signal multi end
                return;
            }
            else
            {
                //Single Special Key
                parts = new String[1];
                parts[0] = comline.toString();
                String sect = parts[0].replaceAll(" ", "");
                if(getKeyCode(sect) > 0)
                {
                    sendData(getKeyCode(sect) & 0xff);
                }
                return;
            }

        }
 }
}